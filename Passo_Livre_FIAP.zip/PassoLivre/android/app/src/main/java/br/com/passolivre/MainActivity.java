package br.com.passolivre;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {}
