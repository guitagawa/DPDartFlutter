import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

class Ocorrencia {
  final int? id;
  final String local;
  final String problema;
  final bool resolvido;

  const Ocorrencia(this.local, this.problema, this.resolvido, {this.id});

  Map<String, Object> paraBanco() => {
    'local': local,
    'problema': problema,
    'resolvido': resolvido ? 1 : 0,
  };

  factory Ocorrencia.daLinha(Map<String, Object?> linha) => Ocorrencia(
    linha['local'] as String, linha['problema'] as String,
    linha['resolvido'] == 1, id: linha['id'] as int,
  );
}

class Registros extends ChangeNotifier {
  late Database banco;
  List<Ocorrencia> itens = [];
  bool carregando = true;
  bool falhou = false;

  Future<void> iniciar() async {
    carregando = true;
    falhou = false;
    notifyListeners();
    try {
      banco = await openDatabase('passo_livre.db', version: 1,
        onCreate: (db, versao) async {
          await db.execute('CREATE TABLE ocorrencias (id INTEGER PRIMARY KEY, local TEXT NOT NULL, problema TEXT NOT NULL, resolvido INTEGER NOT NULL)');
        },
      );
      final linhas = await banco.query('ocorrencias', orderBy: 'id DESC');
      itens = linhas.map(Ocorrencia.daLinha).toList();
    } catch (_) {
      falhou = true;
    } finally {
      carregando = false;
      notifyListeners();
    }
  }

  Future<void> salvar(Ocorrencia item) async {
    if (item.id == null) {
      final id = await banco.insert('ocorrencias', item.paraBanco());
      itens.insert(0, Ocorrencia(item.local, item.problema, item.resolvido, id: id));
    } else {
      await banco.update('ocorrencias', item.paraBanco(), where: 'id = ?', whereArgs: [item.id]);
      itens[itens.indexWhere((o) => o.id == item.id)] = item;
    }
    notifyListeners();
  }

  Future<void> excluir(int id) async {
    await banco.delete('ocorrencias', where: 'id = ?', whereArgs: [id]);
    itens.removeWhere((item) => item.id == id);
    notifyListeners();
  }
}
