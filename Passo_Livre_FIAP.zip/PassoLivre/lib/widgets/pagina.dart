import 'package:flutter/material.dart';

class Pagina extends StatelessWidget {
  final String titulo;
  final List<Widget> filhos;
  const Pagina(this.titulo, this.filhos, {super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(titulo)),
    body: SafeArea(child: SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [for (final filho in filhos)
          Padding(padding: const EdgeInsets.only(bottom: 12), child: filho)],
      ),
    )),
  );
}

Future<void> abrir(BuildContext context, Widget tela) async {
  await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => tela));
}
