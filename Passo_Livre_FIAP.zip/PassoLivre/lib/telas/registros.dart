import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../dados.dart';
import '../widgets/pagina.dart';
import 'formulario.dart';

class Lista extends StatelessWidget {
  const Lista({super.key});

  @override
  Widget build(BuildContext context) {
    final itens = context.watch<Registros>().itens;
    return Pagina('Registros', [
      if (itens.isEmpty) const Text('Nenhum problema registrado no bairro.'),
      for (final item in itens)
        Card(child: ListTile(title: Text(item.local), subtitle: Text(item.problema),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => abrir(context, Detalhes(item.id!)))),
    ]);
  }
}

class Detalhes extends StatelessWidget {
  final int id;
  const Detalhes(this.id, {super.key});

  Future<void> confirmar(BuildContext context) async {
    final apagar = await showDialog<bool>(context: context, builder: (dialogo) =>
      AlertDialog(title: const Text('Excluir registro?'), content: const Text('O registro será removido deste aparelho.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogo, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(dialogo, true), child: const Text('Excluir')),
        ]));
    if (apagar != true || !context.mounted) return;
    try {
      await context.read<Registros>().excluir(id);
      if (context.mounted) Navigator.pop(context);
    } catch (_) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Falha ao excluir o registro.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final item = context.watch<Registros>().itens.where((o) => o.id == id).firstOrNull;
    if (item == null) return const Pagina('Detalhes', []);
    return Pagina('Detalhes', [
      Text(item.local, style: Theme.of(context).textTheme.headlineSmall),
      Text(item.problema),
      Text(item.resolvido ? 'Situação: resolvido' : 'Situação: em aberto'),
      FilledButton(onPressed: () => abrir(context, Formulario(item: item)), child: const Text('Editar')),
      OutlinedButton(onPressed: () => confirmar(context), child: const Text('Excluir')),
    ]);
  }
}
