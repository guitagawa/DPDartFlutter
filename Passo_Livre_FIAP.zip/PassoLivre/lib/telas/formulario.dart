import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../dados.dart';
import '../widgets/pagina.dart';

class Formulario extends StatefulWidget {
  final Ocorrencia? item;
  const Formulario({super.key, this.item});

  @override
  State<Formulario> createState() => _FormularioState();
}

class _FormularioState extends State<Formulario> {
  final chave = GlobalKey<FormState>();
  late final local = TextEditingController(text: widget.item?.local);
  late final problema = TextEditingController(text: widget.item?.problema);
  late bool resolvido = widget.item?.resolvido ?? false;
  bool salvando = false;

  @override
  void dispose() {
    local.dispose();
    problema.dispose();
    super.dispose();
  }

  Future<void> salvar() async {
    if (!chave.currentState!.validate() || salvando) return;
    setState(() => salvando = true);
    final mensagens = ScaffoldMessenger.of(context);
    try {
      await context.read<Registros>().salvar(Ocorrencia(local.text.trim(),
        problema.text.trim(), resolvido, id: widget.item?.id));
      if (!mounted) return;
      Navigator.pop(context);
      mensagens.showSnackBar(SnackBar(content: Text(widget.item == null ? 'Registro criado.' : 'Registro atualizado.')));
    } catch (_) {
      if (!mounted) return;
      setState(() => salvando = false);
      mensagens.showSnackBar(const SnackBar(content: Text('Falha ao salvar. Tente novamente.')));
    }
  }

  @override
  Widget build(BuildContext context) => Pagina(widget.item == null ? 'Novo registro' : 'Editar registro', [
    Form(key: chave, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextFormField(controller: local, decoration: const InputDecoration(labelText: 'Rua e referência'),
        validator: (valor) => (valor ?? '').trim().isEmpty ? 'Informe o local.' : null),
      const SizedBox(height: 16),
      TextFormField(controller: problema, maxLines: 3, decoration: const InputDecoration(labelText: 'Problema encontrado'),
        validator: (valor) => (valor ?? '').trim().isEmpty ? 'Descreva o problema.' : null),
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Problema resolvido'),
        value: resolvido, onChanged: (valor) => setState(() => resolvido = valor)),
      FilledButton(onPressed: salvando ? null : salvar, child: const Text('Salvar')),
    ])),
  ]);
}
