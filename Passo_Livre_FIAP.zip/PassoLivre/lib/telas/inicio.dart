import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../dados.dart';
import '../widgets/pagina.dart';
import 'formulario.dart';
import 'registros.dart';

class Inicio extends StatelessWidget {
  const Inicio({super.key});

  @override
  Widget build(BuildContext context) {
    final dados = context.watch<Registros>();
    if (dados.carregando) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (dados.falhou) {
      return Pagina('Passo Livre', [
        const Text('Não foi possível abrir os registros.'),
        FilledButton(onPressed: dados.iniciar, child: const Text('Tentar novamente')),
      ]);
    }
    final abertos = dados.itens.where((o) => !o.resolvido).length;
    return Pagina('Passo Livre', [
      Text('Calçadas do bairro', style: Theme.of(context).textTheme.headlineMedium),
      const Text('Registre obstáculos no caminho e acompanhe quais já foram resolvidos.'),
      Card(child: ListTile(leading: const Icon(Icons.directions_walk),
        title: Text('$abertos em aberto'), subtitle: Text('${dados.itens.length} registros no total'))),
      FilledButton(onPressed: () => abrir(context, const Formulario()), child: const Text('Registrar problema')),
      OutlinedButton(onPressed: () => abrir(context, const Lista()), child: const Text('Ver registros')),
      TextButton(onPressed: () => abrir(context, const Sobre()), child: const Text('Sobre o ODS 11')),
    ]);
  }
}

class Sobre extends StatelessWidget {
  const Sobre({super.key});

  @override
  Widget build(BuildContext context) => const Pagina('Sobre o projeto', [
    Icon(Icons.location_city, size: 48),
    Text('ODS 11 · Cidades e comunidades sustentáveis', style: TextStyle(fontSize: 22)),
    Text('Uma calçada sem rampa pode interromper o trajeto de quem usa cadeira de rodas. O Passo Livre ajuda moradores a registrar esses pontos e acompanhar as melhorias no próprio aparelho.'),
  ]);
}
