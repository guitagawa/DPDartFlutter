import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dados.dart';
import 'telas/inicio.dart';

void main() {
  runApp(ChangeNotifierProvider(create: (_) => Registros()..iniciar(), child: const PassoLivre()));
}

class PassoLivre extends StatelessWidget {
  const PassoLivre({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Passo Livre',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: const Color(0xff186447), useMaterial3: true,
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder())),
    home: const Inicio(),
  );
}
